﻿using System;
using System.IO;
using System.Net;
using System.Web; // Add Reference System.Web
using System.Text;
using System.Text.RegularExpressions;

namespace ConsoleApplication1
{
    class FORM
    {
        static void Main(string[] args)
        {
            Uri uri = new Uri("http://sms.dialogue.net/submit_sm");
            WebRequest webRequest = WebRequest.Create(uri);
            webRequest.Method = "POST";
            webRequest.ContentType = "application/x-www-form-urlencoded; charset=UTF-8";
            // TODO: provide user name and password
            webRequest.Credentials = new NetworkCredential(
                "...", "..."
            );

            Encoding encoding = new UTF8Encoding();
            StreamWriter writer = new StreamWriter(webRequest.GetRequestStream(), encoding);
            writer.Write(
                "X-E3-Message=" + HttpUtility.UrlEncode("This is a test message", encoding) + "&" +
                "X-E3-Message=" + HttpUtility.UrlEncode("This is another test message", encoding) + "&" +
                // TODO: provide recipient number(s)
                "X-E3-Recipients=" + HttpUtility.UrlEncode("...", encoding) + "&" +
                "X-E3-Recipients=" + HttpUtility.UrlEncode("...", encoding) + "&" +
                "X-E3-Originating-Address=" + HttpUtility.UrlEncode("Sender", encoding) + "&"              
            );
            writer.Close();

            WebResponse webResponse = webRequest.GetResponse();

            StreamReader reader = new StreamReader(webResponse.GetResponseStream(), encoding);
            while (reader.Peek() >= 0)
            {
                string line = reader.ReadLine();                                    
                Match m = Regex.Match(line, "X-E3-Recipients: \"(.*)\" X-E3-Submission-Report: \"00\" X-E3-ID: \"(.*)\"");
                if (m.Success)
                {
                    Console.WriteLine("Submission to '{0}' successful; " +
                        "messageId: {1}",
                            m.Groups[1].Value,
                            m.Groups[2].Value
                    );
                }
                else
                {
                    m = Regex.Match(line, "X-E3-Recipients: \"(.*)\" X-E3-Submission-Report: \"(.*)\" X-E3-Error-Description: \"(.*)\"");
                    if (m.Success)
                    {
                        Console.WriteLine("Submission to '{0}' failed; " +
                            "errorCode: {1}, errorDescription: {2}",
                                m.Groups[1].Value,
                                m.Groups[2].Value,
                                m.Groups[3].Value
                        );
                    }
                }
            }

            Console.ReadKey();
        }
    }
}
