﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ConsoleApplication1
{
    public class XML
    {
        [XmlRoot("sendSmsRequest")]
        public class SendSmsRequest
        {
            [XmlElement("X-E3-Message", typeof(String))]
            public List<String> X_E3_Message { get; set; }

            [XmlElement("X-E3-Recipients", typeof(String))]
            public List<String> X_E3_Recipients { get; set; }

            [XmlElement("X-E3-Originating-Address")]
            public String X_E3_Originating_Address { get; set; }
        }

        [XmlRoot("sms")]
        public class Sms
        {
            [XmlAttribute("X-E3-ID")]
            public String X_E3_ID { get; set; }
            [XmlAttribute("X-E3-Recipients")]
            public String X_E3_Recipients { get; set; }
            [XmlAttribute("X-E3-Submission-Report")]
            public String X_E3_Submission_Report { get; set; }
            [XmlAttribute("X-E3-Error-Description")]
            public String X_E3_Error_Description { get; set; }
        }

        [XmlRoot("sendSmsResponse")]
        public class SendSmsResponse
        {
            [XmlElement("sms", typeof(Sms))]
            public List<Sms> sms { get; set; }

            public SendSmsResponse() { sms = new List<Sms>(); }
        }

        static SendSmsResponse SubmitMessage(
            SendSmsRequest sendSmsRequest, 
            NetworkCredential credentials)
        {
            Uri uri = new Uri("http://sms.dialogue.net/submit_sm");
            WebRequest webRequest = WebRequest.Create(uri);
            webRequest.Method = "POST";
            webRequest.ContentType = "application/xml; charset=UTF-8";
            webRequest.Credentials = credentials;
            
            XmlSerializer serializer1 = new XmlSerializer(typeof(SendSmsRequest));                            
            serializer1.Serialize(webRequest.GetRequestStream(), sendSmsRequest);                      

            WebResponse webResponse = webRequest.GetResponse();

            XmlSerializer serializer2 = new XmlSerializer(typeof(SendSmsResponse));
            return serializer2.Deserialize(
                webResponse.GetResponseStream()) as SendSmsResponse;
        }

        static void Main(string[] args)
        {
            SendSmsRequest sendSmsRequest = new SendSmsRequest()
            {
                X_E3_Message = new List<string> {
                    "This is a test message", 
                    "This is another message"
                },
                // TODO: provide recipient number(s)
                X_E3_Recipients = new List<string>{ 
                    "...", 
                    "..." 
                },
                X_E3_Originating_Address = "Sender"
            };

            // TODO: provide user name and password
            NetworkCredential credentials = new NetworkCredential(
                "...", "..."
            );

            SendSmsResponse sendSmsResponse = SubmitMessage(
                sendSmsRequest, credentials
            );

            foreach (Sms sms in sendSmsResponse.sms)
            {
                if ("00" == sms.X_E3_Submission_Report)
                {
                    Console.WriteLine("Submission to '{0}' successful; " +
                        "messageId: {1}",
                            sms.X_E3_Recipients,
                            sms.X_E3_ID
                    );
                }
                else
                {
                    Console.WriteLine("Submission to '{0}' failed; " +
                        "errorCode: {1}, errorDescription: {2}",
                            sms.X_E3_Recipients,
                            sms.X_E3_Submission_Report,
                            sms.X_E3_Error_Description
                    );
                }
            }
           
            Console.ReadKey();
        }
    }
}