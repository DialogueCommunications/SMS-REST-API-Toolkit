﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Collections.Generic;
using System.Runtime.Serialization; // Add Reference System.Runtime.Serialization
using System.Runtime.Serialization.Json;

namespace ConsoleApplication1
{
    public class JSON
    {
        [DataContract]
        public class SendSmsRequest
        {
            [DataMember(Name = "X-E3-Message")]
            public List<string> X_E3_Message { get; set; }

            [DataMember(Name = "X-E3-Recipients")]
            public List<string> X_E3_Recipients { get; set; }

            [DataMember(Name = "X-E3-Originating_Address")]
            public string X_E3_Originating_Address { get; set; }
        }

        [DataContract]
        public class Sms
        {
            [DataMember(Name = "X-E3-ID")]
            public String X_E3_ID { get; set; }
            [DataMember(Name = "X-E3-Recipients")]
            public String X_E3_Recipients { get; set; }
            [DataMember(Name = "X-E3-Submission-Report")]
            public String X_E3_Submission_Report { get; set; }
            [DataMember(Name = "X-E3-Error-Description")]
            public String X_E3_Error_Description { get; set; }
        }

        [DataContract]
        public class SendSmsResponse
        {
            [DataMember(Name = "sms")]
            public List<Sms> sms { get; set; }

            public SendSmsResponse() { sms = new List<Sms>(); }
        }

        static SendSmsResponse SubmitMessage(
            SendSmsRequest sendSmsRequest,
            NetworkCredential credentials)
        {
            WebRequest webRequest = WebRequest.Create(
                new Uri("http://sms.dialogue.net/submit_sm")
            );
            webRequest.Method = "POST";
            webRequest.ContentType = "application/json; charset=UTF-8";
            webRequest.Credentials = credentials;

            DataContractJsonSerializer serializer1 =
                new DataContractJsonSerializer(typeof(SendSmsRequest));
            serializer1.WriteObject(webRequest.GetRequestStream(), sendSmsRequest);

            WebResponse webResponse = webRequest.GetResponse();

            DataContractJsonSerializer serializer2 =
                new DataContractJsonSerializer(typeof(SendSmsResponse));
            return serializer2.ReadObject(
                webResponse.GetResponseStream()) as SendSmsResponse;
        }

        static void Main(string[] args)
        {
            SendSmsRequest sendSmsRequest = new SendSmsRequest()
            {
                X_E3_Message = new List<string> {
                    "This is a test message", 
                    "This is another message"
                },
                // TODO: provide recipient number(s)
                X_E3_Recipients = new List<string>{ 
                    "...", 
                    "..." 
                },
                X_E3_Originating_Address = "Sender"
            };

            // TODO: provide user name and password
            NetworkCredential credentials = new NetworkCredential(
                "...", "..."
            );

            SendSmsResponse sendSmsResponse = SubmitMessage(
                sendSmsRequest, credentials
            );

            foreach (Sms sms in sendSmsResponse.sms)
            {
                if ("00" == sms.X_E3_Submission_Report)
                {
                    Console.WriteLine("Submission to '{0}' successful; " +
                        "messageId: {1}",
                            sms.X_E3_Recipients,
                            sms.X_E3_ID
                    );
                }
                else
                {
                    Console.WriteLine("Submission to '{0}' failed; " +
                        "errorCode: {1}, errorDescription: {2}",
                            sms.X_E3_Recipients,
                            sms.X_E3_Submission_Report,
                            sms.X_E3_Error_Description
                    );
                }
            }

            Console.ReadKey();
        }
    }
}
