﻿using System;
using System.Net;
using System.Text;

namespace ConsoleApplication1
{
    class Utils
    {
        public static void SetBasicAuthHeader(
           WebRequest webRequest,
           NetworkCredential credentials)
        {
            string authInfo = credentials.UserName + ":" + credentials.Password;
            authInfo = Convert.ToBase64String(Encoding.Default.GetBytes(authInfo));
            webRequest.Headers["Authorization"] = "Basic " + authInfo;
        }

        public static string decodeHexMessage(string hexMessage)
        {            
            byte[] data = new byte[hexMessage.Length / 2];
            for (int i = 0; i < data.Length; i++)
                data[i] = Convert.ToByte(hexMessage.Substring(i * 2, 2), 16);
            return Encoding.GetEncoding("ISO-8859-15").GetString(data);
        }
    }
}
