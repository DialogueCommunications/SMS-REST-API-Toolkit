<?php
function submitMessage($xml, $userName, $password) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'http://sms.dialogue.net/submit_sm');
  curl_setopt($ch, CURLOPT_HTTPHEADER, array (
    'Content-Type: application/xml; charset=UTF-8'
  ));
  curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
  curl_setopt($ch, CURLOPT_USERPWD, $userName . ':' . $password);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  $response = curl_exec($ch);
  curl_close($ch);
  return $response;
}

// TODO: provide recipient number(s)
$xml = 
  '<sendSmsRequest>' .
  '  <X-E3-Message>This is a test message</X-E3-Message>' .
  '  <X-E3-Message>This is another message</X-E3-Message>' .
  '  <X-E3-Recipients>...</X-E3-Recipients>' .
  '  <X-E3-Recipients>...</X-E3-Recipients>' .
  '  <X-E3-Originating-Address>Sender</X-E3-Originating-Address>' .
  '</sendSmsRequest>';
// TODO: provide user name and password
$userName = '...';
$password = '...';

$response = submitMessage($xml, $userName, $password);

function startElement($parser, $name, $attrs) {
  if ($name == 'SMS') {
    if ($attrs['X-E3-SUBMISSION-REPORT'] == '00') {
      print 'Submission to \'' . $attrs['X-E3-RECIPIENTS'] . '\' successful; ' .
      'messageId: ' . $attrs['X-E3-ID'] . "\n";
    } else {
      print 'Submission to \'' . $attrs['X-E3-RECIPIENTS'] . '\' failed; ' .
      'errorCode: ' . $attrs['X-E3-SUBMISSION-REPORT'] .
      ', errorDescription: ' . $attrs['X-E3-ERROR-DESCRIPTION'] . "\n";
    }
  }
}

$parser = xml_parser_create();
xml_set_element_handler($parser, 'startElement', null);
xml_parse($parser, $response);
xml_parser_free($parser);
?>