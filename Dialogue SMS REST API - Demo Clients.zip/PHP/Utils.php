<?php
function decodeHexMessage($hexMessage) {
	// TODO: replace "CP1252" by desired output encoding
	return iconv("ISO-8859-15", "CP1252", pack("H*" , $hexMessage)); 
}
// TODO: replace ... by hex-encoded ISO-8859-15/Latin9 string
print decodeHexMessage("..."). "\n"; 
?>