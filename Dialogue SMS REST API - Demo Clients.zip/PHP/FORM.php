<?php
function submitMessage($body, $userName, $password) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'http://sms.dialogue.net/submit_sm');
	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	curl_setopt($ch, CURLOPT_USERPWD, $userName . ':' . $password);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$response = curl_exec($ch);
	curl_close($ch);
	return $response;
}

// TODO: provide recipient number(s)
$body = 
  'X-E3-Message='.urlencode('This is a test message').'&'.
  'X-E3-Message='.urlencode('This is another test message').'&'.
  'X-E3-Recipients='.urlencode('...').'&'.
  'X-E3-Recipients='.urlencode('...').'&'.
  'X-E3-Originating-Address='.urlencode('Sender').'&'.
  '';

// TODO: provide user name and password
$userName = '...';
$password = '...';

$response = submitMessage($body, $userName, $password);

foreach (explode("\n", $response) as $line) {
	if(preg_match("/X-E3-Recipients: \"(.*)\" X-E3-Submission-Report: \"00\" X-E3-ID: \"(.*)\"/", $line, $matches) == 1) {
		print 'Submission to \''.$matches[1]. 
			'\' successful; messageId: '.$matches[2]."\n";
	}
	else {
		if(preg_match("/X-E3-Recipients: \"(.*)\" X-E3-Submission-Report: \"(.*)\" X-E3-Error-Description: \"(.*)\"/", $line, $matches) == 1) {
			print 'Submission to \''.$matches[1].
				'\' failed; errorCode: '.$matches[2].
				', errorDescription: '.$matches[3]."\n";
		}
	}
}
?>