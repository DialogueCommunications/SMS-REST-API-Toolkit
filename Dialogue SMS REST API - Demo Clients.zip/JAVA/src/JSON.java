
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.io.*;
import java.net.*;
import java.text.MessageFormat;
import java.util.*;

public class JSON {

    static class SendSmsRequest {

        @SerializedName("X-E3-Message")
        private List<String> X_E3_Message;

        public List<String> getX_E3_Message() {
            return X_E3_Message;
        }

        public void setX_E3_Message(List<String> x_E3_Message) {
            X_E3_Message = x_E3_Message;
        }
        
        @SerializedName("X-E3-Recipients")
        private List<String> X_E3_Recipients;

        public List<String> getX_E3_Recipients() {
            return X_E3_Recipients;
        }

        public void setX_E3_Recipients(List<String> x_E3_Recipients) {
            X_E3_Recipients = x_E3_Recipients;
        }

        @SerializedName("X-E3-Originating-Address")
        private String X_E3_Originating_Address;

        public String getX_E3_Originating_Address() {
            return X_E3_Originating_Address;
        }

        public void setX_E3_Originating_Address(String x_E3_Originating_Address) {
            X_E3_Originating_Address = x_E3_Originating_Address;
        }
    }

    static class Sms {

        @SerializedName("X-E3-ID")
        private String X_E3_ID;

        public String getX_E3_ID() {
            return X_E3_ID;
        }

        public void setX_E3_ID(String x_E3_ID) {
            X_E3_ID = x_E3_ID;
        }

        @SerializedName("X-E3-Recipients")
        private String X_E3_Recipients;

        public String getX_E3_Recipients() {
            return X_E3_Recipients;
        }

        public void setX_E3_Recipients(String x_E3_Recipients) {
            X_E3_Recipients = x_E3_Recipients;
        }

        @SerializedName("X-E3-Submission-Report")
        private String X_E3_Submission_Report;

        public String getX_E3_Submission_Report() {
            return X_E3_Submission_Report;
        }

        public void setX_E3_Submission_Report(String x_E3_Submission_Report) {
            X_E3_Submission_Report = x_E3_Submission_Report;
        }

        @SerializedName("X-E3-Error-Description")
        private String X_E3_Error_Description;

        public String getX_E3_Error_Description() {
            return X_E3_Error_Description;
        }

        public void setX_E3_Error_Description(String x_E3_Error_Description) {
            X_E3_Error_Description = x_E3_Error_Description;
        }
    }

    static class SendSmsResponse {

        private List<Sms> sms;

        public List<Sms> getSms() {
            return sms;
        }

        public void setSms(List<Sms> sms) {
            this.sms = sms;
        }
    }

    static SendSmsResponse submitMessage(
        SendSmsRequest sendSmsRequest, String userName, String password)
        throws IOException {
        URL url = new URL("http://sms.dialogue.net/submit_sm");
        URLConnection connection = url.openConnection();
        String encoded = new sun.misc.BASE64Encoder().encode(
            (userName + ":" + password).getBytes());
        connection.setRequestProperty("Authorization",
            "Basic " + encoded);
        connection.setRequestProperty("Content-Type",
            "application/json; charset=UTF-8");
        connection.setDoOutput(true);
        OutputStream os = connection.getOutputStream();
        PrintWriter pw = new PrintWriter(os);
        pw.print(new Gson().toJson(sendSmsRequest));
        pw.flush();

        InputStreamReader reader = new InputStreamReader(
            connection.getInputStream(), "UTF-8");
        return new Gson().fromJson(reader, SendSmsResponse.class);
    }

    public static void main(String[] args) throws Exception {

        SendSmsRequest sendSmsRequest = new SendSmsRequest();
        sendSmsRequest.setX_E3_Message(Arrays.asList(
            "This is a test message", "This is another message"));
        // TODO: provide recipient number(s)
        sendSmsRequest.setX_E3_Recipients(Arrays.asList(
            "...", "..."));
        sendSmsRequest.setX_E3_Originating_Address("Sender");

        // TODO: provide user name and password
        String userName = "...", password = "...";

        SendSmsResponse result = submitMessage(
            sendSmsRequest, userName, password);

        for (Sms sms : result.getSms()) {
            if ("00".equals(sms.getX_E3_Submission_Report())) {
                System.out.println(
                    MessageFormat.format(
                        "Submission to ''{0}'' successful; " +
                            "messageId: {1}",
                        sms.getX_E3_Recipients(),
                        sms.getX_E3_ID()
                    )
                );
            } else {
                System.out.println(
                    MessageFormat.format(
                        "Submission to ''{0}'' failed; " +
                            "errorCode: {1}, errorDescription: {2}",
                        sms.getX_E3_Recipients(),
                        sms.getX_E3_Submission_Report(),
                        sms.getX_E3_Error_Description()
                    )
                );
            }
        }
    }
}