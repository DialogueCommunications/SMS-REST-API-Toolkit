import java.io.*;
import java.net.*;
import java.text.MessageFormat;
import java.util.regex.*;

public class FORM {

    public static void main(String[] args) throws Exception {
        URL url = new URL("http://sms.dialogue.net/submit_sm");
        URLConnection connection = url.openConnection();
        String encoded = new sun.misc.BASE64Encoder().encode(
	// TODO: provide user name and password
            "...:...".getBytes());
        connection.setRequestProperty("Authorization", "Basic " + encoded);
        connection.setRequestProperty("Content-Type",
            "application/x-www-form-urlencoded; charset=UTF-8 ");
        connection.setDoOutput(true);

        PrintWriter writer = new PrintWriter(new OutputStreamWriter(
            connection.getOutputStream(), "UTF-8"));

        writer.print("X-E3-Message=" + URLEncoder.encode("This is a test message", "UTF-8") + "&");
        writer.print("X-E3-Message=" + URLEncoder.encode("This is another test message", "UTF-8") + "&");
	// TODO: provide recipient number(s)
        writer.print("X-E3-Recipients=" + URLEncoder.encode("...", "UTF-8") + "&");
        writer.print("X-E3-Recipients=" + URLEncoder.encode("...", "UTF-8") + "&");
        writer.print("X-E3-Originating-Address=" + URLEncoder.encode("Sender", "UTF-8") + "&");
        writer.flush();
        writer.close();

        BufferedReader reader = new BufferedReader(new InputStreamReader(
            connection.getInputStream(), "UTF-8"));

        String line;
        while ((line = reader.readLine()) != null) {
            Matcher success = PATTERNS_SUCCESS.matcher(line);
            if (success.find()) {
                System.out.println(
                    MessageFormat.format(
                        "Submission to ''{0}'' successful; " +
                            "messageId: {1}",
                        success.group(1), // X-E3-Recipients
                        success.group(2) // X-E3-ID
                    )
                );
            } else {
                Matcher failure = PATTERNS_FAILURE.matcher(line);
                if (failure.find()) {
                    System.out.println(
                        MessageFormat.format(
                            "Submission to ''{0}'' failed; " +
                                "errorCode: {1}, errorDescription: {2}",
                            failure.group(1), // X-E3-Recipients
                            failure.group(2), // X-E3-Submission-Report
                            failure.group(3) // X-E3-Error-Description
                        )
                    );
                }
            }
        }
    }

    static Pattern PATTERNS_SUCCESS = Pattern.compile(
        "X-E3-Recipients: \"(.*)\" X-E3-Submission-Report: \"00\" X-E3-ID: \"(.*)\"");
    static Pattern PATTERNS_FAILURE = Pattern.compile(
        "X-E3-Recipients: \"(.*)\" X-E3-Submission-Report: \"(.*)\" X-E3-Error-Description: \"(.*)\"");
}