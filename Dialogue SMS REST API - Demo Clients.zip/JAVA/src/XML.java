import javax.xml.bind.*;
import javax.xml.bind.annotation.*;
import java.io.*;
import java.net.*;
import java.text.MessageFormat;
import java.util.*;

public class XML {

    @XmlRootElement(name = "sendSmsRequest")
    static class SendSmsRequest {

        private List<String> X_E3_Message;

        @XmlElement(name = "X-E3-Message")
        public List<String> getX_E3_Message() {
            return X_E3_Message;
        }

        public void setX_E3_Message(List<String> x_E3_Message) {
            X_E3_Message = x_E3_Message;
        }

        private List<String> X_E3_Recipients;

        @XmlElement(name = "X-E3-Recipients")
        public List<String> getX_E3_Recipients() {
            return X_E3_Recipients;
        }

        public void setX_E3_Recipients(List<String> x_E3_Recipients) {
            X_E3_Recipients = x_E3_Recipients;
        }

        private String X_E3_Originating_Address;

        @XmlElement(name = "X-E3-Originating-Address")
        public String getX_E3_Originating_Address() {
            return X_E3_Originating_Address;
        }

        public void setX_E3_Originating_Address(String x_E3_Originating_Address) {
            X_E3_Originating_Address = x_E3_Originating_Address;
        }
    }

     static class Sms {

        private String X_E3_ID;

        @XmlAttribute(name = "X-E3-ID")
        public String getX_E3_ID() {
            return X_E3_ID;
        }

        public void setX_E3_ID(String x_E3_ID) {
            X_E3_ID = x_E3_ID;
        }

        private String X_E3_Recipients;

        @XmlAttribute(name = "X-E3-Recipients")
        public String getX_E3_Recipients() {
            return X_E3_Recipients;
        }

        public void setX_E3_Recipients(String x_E3_Recipients) {
            X_E3_Recipients = x_E3_Recipients;
        }

        private String X_E3_Submission_Report;

        @XmlAttribute(name = "X-E3-Submission-Report")
        public String getX_E3_Submission_Report() {
            return X_E3_Submission_Report;
        }

        public void setX_E3_Submission_Report(String x_E3_Submission_Report) {
            X_E3_Submission_Report = x_E3_Submission_Report;
        }

        private String X_E3_Error_Description;

        @XmlAttribute(name = "X-E3-Error-Description")
        public String getX_E3_Error_Description() {
            return X_E3_Error_Description;
        }

        public void setX_E3_Error_Description(String x_E3_Error_Description) {
            X_E3_Error_Description = x_E3_Error_Description;
        }
    }

    @XmlRootElement(name = "sendSmsResponse")
    static class SendSmsResponse {

        private List<Sms> sms;

        @XmlElement(name = "sms")
        public List<Sms> getSms() {
            return sms;
        }

        public void setSms(List<Sms> sms) {
            this.sms = sms;
        }
    }

    static SendSmsResponse submitMessage(
        SendSmsRequest sendSmsRequest, String userName, String password)
        throws IOException, JAXBException {
        URL url = new URL("http://sms.dialogue.net/submit_sm");
        URLConnection connection = url.openConnection();
        String encoded = new sun.misc.BASE64Encoder().encode(
            (userName + ":" + password).getBytes());
        connection.setRequestProperty("Authorization", "Basic " + encoded);
        connection.setRequestProperty("Content-Type",
            "application/xml; charset=UTF-8");
        connection.setDoOutput(true);

        JAXBContext context1 = JAXBContext.newInstance(SendSmsRequest.class);
        Marshaller marshaller = context1.createMarshaller();
        marshaller.marshal(sendSmsRequest, connection.getOutputStream());

        JAXBContext context2 = JAXBContext.newInstance(SendSmsResponse.class);
        Unmarshaller unmarshaller = context2.createUnmarshaller();
        return (SendSmsResponse)unmarshaller.unmarshal(connection.getInputStream());
    }

    public static void main(String[] args) throws Exception {

        SendSmsRequest sendSmsRequest = new SendSmsRequest();
        sendSmsRequest.setX_E3_Message(Arrays.asList(
            "This is a test message", "This is another message"));
        // TODO: provide recipient number(s)
        sendSmsRequest.setX_E3_Recipients(Arrays.asList(
            "...", "..."));
        sendSmsRequest.setX_E3_Originating_Address("Sender");

        // TODO: provide user name and password
        String userName = "...", password = "...";

        SendSmsResponse result = submitMessage(
            sendSmsRequest, userName, password);

        for (Sms sms : result.getSms()) {
            if ("00".equals(sms.getX_E3_Submission_Report())) {
                System.out.println(
                    MessageFormat.format(
                        "Submission to ''{0}'' successful; " +
                            "messageId: {1}",
                        sms.getX_E3_Recipients(),
                        sms.getX_E3_ID()
                    )
                );
            } else {
                System.out.println(
                    MessageFormat.format(
                        "Submission to ''{0}'' failed; " +
                            "errorCode: {1}, errorDescription: {2}",
                        sms.getX_E3_Recipients(),
                        sms.getX_E3_Submission_Report(),
                        sms.getX_E3_Error_Description()
                    )
                );
            }
        }
    }
}