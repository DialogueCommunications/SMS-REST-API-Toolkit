# toolkit-java

## About

A Java client library to send SMS messages through the Dialogue SMS Toolkit API: http://www.dialogue.net/sms_toolkit/

## Build

    git clone git://github.com/DialogueCommunications/toolkit-java.git
    cd toolkit-java
    ant

## Example Usage

    import net.dialogue.toolkit.sms.*; 
     
    import java.io.IOException; 
    import java.util.Arrays; 
     
    public class Main 
    { 
        public static void main(String[] args) 
        { 
            SendSmsClient client = new SendSmsClient( 
                new Credentials("user", "pass") 
            ); 
     
            SendSmsRequest request = new SendSmsRequest( 
                Arrays.asList("This is a test message"), 
                Arrays.asList("44xxxxxxxxxx") 
            ); 
     
            try 
            { 
                SendSmsResponse response = client.sendSms(request); 
            } 
            catch(IOException e) 
            { 
                e.printStackTrace(); 
            } 
        } 
    }

## References

* [Java Quick Start Guide][quick_start_guide]

 [quick_start_guide]: http://www.dialogue.net/sms_toolkit/documents/Dialogue_Partner_Toolkit_Quick_Start_Guide_Java.pdf

## Contribute

If you would like to contribute to toolkit-java then fork the project, implement your feature/plugin on a new branch and send a pull request.
