package net.dialogue.toolkit.sms;

import java.io.Serializable;

/**
 * Credentials object containing username and password.
 */
public final class Credentials implements Serializable {

    private String userName;
    private char[] password;

    /**
     * Creates a new Credentials instance using a string as password.
     * @param userName The username
     * @param password The password
     * @throws IllegalArgumentException If userName or password is null or empty.
     */
    public Credentials(String userName, String password) {
        setUserName(userName);
        setPassword(password);
    }

    /**
     * Creates a new Credentials instance using a char array as password.
     * @param userName The username
     * @param password The password as char array
     * @throws IllegalArgumentException If userName or password is null or empty.
     */
    public Credentials(String userName, char[] password) {
        setUserName(userName);
        setPassword(password);
    }

    /**
     * Gets the Username property.
     * @return The username
     * @see Credentials#setUserName(String)
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the Username property.
     * @param userName The username
     * @throws IllegalArgumentException If userName is null or empty.
     */
    public void setUserName(String userName) {
        if (userName == null || userName.length() == 0) {
            throw new IllegalArgumentException(
                    "No userName provided."
            );
        }

        this.userName = userName;
    }

    /**
     * Gets the Password property.
     * @return The password as char array
     * @see Credentials#setPassword(char[])
     */
    public char[] getPassword() {
        return password;
    }

    /**
     * Sets the Password property.
     * @param password The password as char array
     * @throws IllegalArgumentException If password is null or empty.
     */
    public void setPassword(char[] password) {
        if (password == null || password.length == 0) {
            throw new IllegalArgumentException(
                    "No password provided."
            );
        }

        this.password = password;
    }

    /**
     * Sets Password property.
     * @param password The password
     * @throws IllegalArgumentException If password is null or empty.
     */
    public void setPassword(String password) {
        if (password == null || password.length() == 0) {
            throw new IllegalArgumentException(
                    "No password provided."
            );
        }

        setPassword(password.toCharArray());
    }
}