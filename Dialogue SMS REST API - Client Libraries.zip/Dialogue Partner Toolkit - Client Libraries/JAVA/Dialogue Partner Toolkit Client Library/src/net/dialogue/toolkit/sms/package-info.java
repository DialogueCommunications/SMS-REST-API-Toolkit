/** Package containing the Dialogue Partner Toolkit Client Library */
package net.dialogue.toolkit.sms;