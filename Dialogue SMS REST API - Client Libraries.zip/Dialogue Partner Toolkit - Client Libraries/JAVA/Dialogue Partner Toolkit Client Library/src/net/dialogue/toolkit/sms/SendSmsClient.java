package net.dialogue.toolkit.sms;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Properties;

/**
 * Client used for sending messages.
 */
public class SendSmsClient {

    /**
     * Creates a new SendSmsClient instance with the given API endpoint and API credentials.
     * @param endpoint The endpoint (host name) used for sending messages
     * @param credentials The credentials (username, password) used for sending messages
     * @throws IllegalArgumentException Thrown if endpoint or credentials is null or empty
     */
    public SendSmsClient(String endpoint, Credentials credentials) {
        setEndpoint(endpoint);
        setCredentials(credentials);
        path = "/submit_sm";
    }

    private String endpoint;

    /**
     * Gets the Endpoint property.
     * @return The endpoint (host name) used for sending messages
     * @see SendSmsClient#setEndpoint(String)
     */
    public String getEndpoint() {
        return endpoint;
    }

    /**
     * Sets the Endpoint property.
     * @param endpoint The endpoint (host name) used for sending messages
     * @throws IllegalArgumentException Thrown if endpoint is null or empty
     */
    public void setEndpoint(String endpoint) {
        if (endpoint == null || endpoint.length() == 0) {
            throw new IllegalArgumentException(
                    "No endpoint provided."
            );
        }

        this.endpoint = endpoint;
    }

    private Credentials credentials;

    /**
     * Gets the Credentials property.
     * @return The credentials (username, password) used for sending messages
     * @see SendSmsClient#setCredentials(Credentials)
     */
    public Credentials getCredentials() {
        return credentials;
    }

    /**
     * Sets the Credentials property.
     * @param credentials The credentials (username, password) used for sending messages
     * @throws IllegalArgumentException Thrown if credentials is null
     */
    public void setCredentials(Credentials credentials) {
        if (credentials == null) {
            throw new IllegalArgumentException(
                    "No credentials provided."
            );
        }

        this.credentials = credentials;
    }

    private String path;

    /**
     * Gets the Path property.
     * @return The path used for sending messages
     * @see SendSmsClient#setPath(String)
     */
    public String getPath() {
        return path;
    }

    /**
     * Sets the Path property. Normally you should not and don't need to modify this.
     * @param path The path used for sending messages
     * @throws IllegalArgumentException Thrown if path is null, empty or does not start with /
     */
    public void setPath(String path) {
        if (path == null || path.length() == 0) {
            throw new IllegalArgumentException(
                    "No path provided."
            );
        }

        if (!path.startsWith("/")) {
            throw new IllegalArgumentException(
                    "The path must start with '/'."
            );
        }

        this.path = path;
    }

    private boolean secure = true;

    /**
     * Gets the Secure property.
     * @return True if secure communication (SSL) is used; false otherwise.
     * @see SendSmsClient#setSecure(boolean)
     */
    public boolean getSecure() {
        return secure;
    }

    /**
     * Sets the Secure property. By default secure communication is enabled and we recommended that you don't change this property.
     * @param secure True if secure communication (SSL) is used; false otherwise.
     */
    public void setSecure(boolean secure) {
        this.secure = secure;
    }

    /**
     * Performs the message submission.
     * @param request Request object containing message(s), recipient(s) and other optional properties
     * @return Response object containing a list of one or more submitted messages
     * @throws IOException Thrown if there is a networking or communication problem with the endpoint
     */
    public SendSmsResponse sendSms(SendSmsRequest request) throws IOException {
        String s = credentials.getUserName() + ":" + new String(credentials.getPassword());
        String encoded = Base64.encodeToString(s.getBytes(), false);

        URL url = new URL(new URL(secure ? "https" : "http", endpoint, ""), path);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setDoInput(true);
        connection.setUseCaches(false);
        connection.setAllowUserInteraction(false);
        connection.setRequestProperty("Authorization", "Basic " + encoded);
        connection.setRequestProperty("Content-Type",
                "application/xml; charset=UTF-8");

        OutputStreamWriter writer = new OutputStreamWriter(
                connection.getOutputStream(), "UTF-8");
        request.writeDocument(writer, new Properties());
        writer.flush();
        writer.close();

        try {
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Document document;
            try {
                InputStream is = connection.getInputStream();

                // While the Sun VM throws an IOException for things like 401 status codes
                // Google AppEngine does not, so we explicitly check the status code and
                // manually throw the IOException (formatted the same way)
                int responseCode = connection.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new IOException(
                            "Server returned HTTP response code: " + responseCode + " for URL: " + url
                    );
                }

                try {
                    document = documentBuilder.parse(is);
                } finally {
                    is.close();
                }
            } catch (IOException e) {
                // Forward exception appending error stream
                // as text to exception message

                StringBuilder buffer = new StringBuilder();

                try {
                    InputStream es = connection.getErrorStream();

                    try {
                        byte[] bytes = new byte[1024];
                        int read;
                        while (true) {
                            read = es.read(bytes, 0, bytes.length);
                            if (read == -1)
                                break;
                            if (read > 0)
                                buffer.append(new String(bytes, 0, read));
                        }
                    } finally {
                        es.close();
                    }
                } catch (Exception ignored) {
                }

                throw new IOException(e.getMessage() + " [" + buffer.toString().trim() + "]");
            }

            SendSmsResponse sendSmsResponse = new SendSmsResponse();
            List<Sms> messages = sendSmsResponse.getMessages();
            NodeList nodeList = document.getElementsByTagName("sms");
            for (int n = 0; n < nodeList.getLength(); n++) {
                Element smsElement = (Element) nodeList.item(n);
                Sms sms = new Sms();
                sms.setId(smsElement.getAttribute("X-E3-ID"));
                sms.setRecipient(smsElement.getAttribute("X-E3-Recipients"));
                sms.setSubmissionReport(smsElement.getAttribute("X-E3-Submission-Report"));
                sms.setErrorDescription(smsElement.getAttribute("X-E3-Error-Description"));
                messages.add(sms);
            }

            return sendSmsResponse;
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new IOException(e.toString());
        }
    }
}
