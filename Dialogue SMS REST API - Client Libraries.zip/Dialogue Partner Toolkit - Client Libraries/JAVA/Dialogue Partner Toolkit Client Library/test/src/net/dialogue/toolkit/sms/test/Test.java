package net.dialogue.toolkit.sms.test;

import net.dialogue.toolkit.sms.*;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.util.*;

public class Test {

    private static void assertException(Runnable runnable, Class<? extends Throwable> clazz, String message) {
        try {
            runnable.run();
            assert false : "Exception expected";
        } catch (Throwable t) {
            if (t.getCause() != null)
                t = t.getCause();

            assert clazz.isAssignableFrom(t.getClass());
            assert t.toString().contains(message) :
                    "'" + t.toString() + "' does not contain '" + message + "'.";
        }
    }

    private static final List<String> EMPTY_STRING_LIST = Collections.emptyList();

    private static final long WEEK = 1000 * 60 * 60 * 24 * 7;
    private static final long DAY = 1000 * 60 * 60 * 24;
    private static final long HOUR = 1000 * 60 * 60;
    private static final long MINUTE = 1000 * 60;

    public static void main(String[] args) throws MalformedURLException {

        //
        // Credentials constructors
        //

        {
            // userName=null
            assertException(new Runnable() {
                public void run() {
                    new Credentials(null, "pass");
                }
            }, IllegalArgumentException.class, "No userName provided.");

            // userName=""
            assertException(new Runnable() {
                public void run() {
                    new Credentials("", "pass");
                }
            }, IllegalArgumentException.class, "No userName provided.");

            // password=(char[])null
            assertException(new Runnable() {
                public void run() {
                    new Credentials("user", (char[]) null);
                }
            }, IllegalArgumentException.class, "No password provided.");

            // password=(String)null
            assertException(new Runnable() {
                public void run() {
                    new Credentials("user", (String) null);
                }
            }, IllegalArgumentException.class, "No password provided.");

            // password=""
            assertException(new Runnable() {
                public void run() {
                    new Credentials("user", "");
                }
            }, IllegalArgumentException.class, "No password provided.");

            //
            // Credentials constructor setters
            //

            final Credentials credentials = new Credentials("user", "pass");

            // userName=null
            assertException(new Runnable() {
                public void run() {
                    credentials.setUserName(null);
                }
            }, IllegalArgumentException.class, "No userName provided.");

            // userName=""
            assertException(new Runnable() {
                public void run() {
                    credentials.setUserName("");
                }
            }, IllegalArgumentException.class, "No userName provided.");

            // password=(char[])null
            assertException(new Runnable() {
                public void run() {
                    credentials.setPassword((char[]) null);
                }
            }, IllegalArgumentException.class, "No password provided.");

            // password=(String)null
            assertException(new Runnable() {
                public void run() {
                    credentials.setPassword((String) null);
                }
            }, IllegalArgumentException.class, "No password provided.");

            // password=""
            assertException(new Runnable() {
                public void run() {
                    credentials.setPassword("");
                }
            }, IllegalArgumentException.class, "No password provided.");
        }

        //
        // Credentials constructor getters
        //

        {
            final Credentials credentials = new Credentials("user", "pass");

            assert "user".equals(credentials.getUserName());
            credentials.setUserName("user2");
            assert "user2".equals(credentials.getUserName());

            assert "pass".equals(new String(credentials.getPassword()));
            credentials.setPassword("pass2");
            assert "pass2".equals(new String(credentials.getPassword()));
            credentials.setPassword("pass3".toCharArray());
            assert "pass3".equals(new String(credentials.getPassword()));
        }

        //
        // SmsSendRequest constructors
        //

        {
            // message=(String)null
            assertException(new Runnable() {
                public void run() {
                    new SendSmsRequest((String) null, "recipient");
                }
            }, IllegalArgumentException.class, "No message provided.");

            // message=""
            assertException(new Runnable() {
                public void run() {
                    new SendSmsRequest("", "recipient");
                }
            }, IllegalArgumentException.class, "No message provided.");

            // messages=(List)null
            assertException(new Runnable() {
                public void run() {
                    new SendSmsRequest((List) null, "recipient");
                }
            }, IllegalArgumentException.class, "No messages provided.");

            // messages=<empty list>
            assertException(new Runnable() {
                public void run() {
                    new SendSmsRequest(EMPTY_STRING_LIST, "recipient");
                }
            }, IllegalArgumentException.class, "No messages provided.");

            // recipient=(String)null
            assertException(new Runnable() {
                public void run() {
                    new SendSmsRequest("message", (String) null);
                }
            }, IllegalArgumentException.class, "No recipient provided.");

            // recipient=""
            assertException(new Runnable() {
                public void run() {
                    new SendSmsRequest("message", "");
                }
            }, IllegalArgumentException.class, "No recipient provided.");

            // recipients=(List)null
            assertException(new Runnable() {
                public void run() {
                    new SendSmsRequest("message", (List) null);
                }
            }, IllegalArgumentException.class, "No recipients provided.");

            // recipients=<empty list>
            assertException(new Runnable() {
                public void run() {
                    new SendSmsRequest("message", EMPTY_STRING_LIST);
                }
            }, IllegalArgumentException.class, "No recipients provided.");
        }

        //
        // SmsSendRequest constructor setters
        //

        {
            final SendSmsRequest request = new SendSmsRequest("message", "recipient");

            // message=(String)null
            assertException(new Runnable() {
                public void run() {
                    request.setMessage(null);
                }
            }, IllegalArgumentException.class, "No message provided.");

            // message=""
            assertException(new Runnable() {
                public void run() {
                    request.setMessage("");
                }
            }, IllegalArgumentException.class, "No message provided.");

            // messages=(List)null
            assertException(new Runnable() {
                public void run() {
                    request.setMessages(null);
                }
            }, IllegalArgumentException.class, "No messages provided.");

            // messages=<empty list>
            assertException(new Runnable() {
                public void run() {
                    request.setMessages(EMPTY_STRING_LIST);
                }
            }, IllegalArgumentException.class, "No messages provided.");

            // recipient=(String)null
            assertException(new Runnable() {
                public void run() {
                    request.setRecipient(null);
                }
            }, IllegalArgumentException.class, "No recipient provided.");

            // recipient=""
            assertException(new Runnable() {
                public void run() {
                    request.setRecipient("");
                }
            }, IllegalArgumentException.class, "No recipient provided.");

            // recipients=(List)null
            assertException(new Runnable() {
                public void run() {
                    request.setRecipients(null);
                }
            }, IllegalArgumentException.class, "No recipients provided.");

            // recipients=<empty list>
            assertException(new Runnable() {
                public void run() {
                    request.setRecipients(EMPTY_STRING_LIST);
                }
            }, IllegalArgumentException.class, "No recipients provided.");
        }

        //
        // SmsSendRequest constructor getters
        //

        {
            SendSmsRequest request;

            request = new SendSmsRequest(
                    "message",
                    "recipient");
            assert Arrays.asList("message").equals(request.getMessages());
            assert Arrays.asList("recipient").equals(request.getRecipients());
            request.setMessage("message2");
            request.setRecipient("recipient2");
            assert Arrays.asList("message2").equals(request.getMessages());
            assert Arrays.asList("recipient2").equals(request.getRecipients());

            request = new SendSmsRequest(
                    Arrays.asList("message", "message2"),
                    Arrays.asList("recipient", "recipient2"));
            assert Arrays.asList("message", "message2").equals(request.getMessages());
            assert Arrays.asList("recipient", "recipient2").equals(request.getRecipients());
            request.setMessages(Arrays.asList("message", "message2", "message3"));
            request.setRecipients(Arrays.asList("recipient", "recipient2", "recipient3"));
            assert Arrays.asList("message", "message2", "message3").equals(request.getMessages());
            assert Arrays.asList("recipient", "recipient2", "recipient3").equals(request.getRecipients());
        }

        //
        // SmsSendRequest other getters/setters
        //

        {
            SendSmsRequest request = new SendSmsRequest("message", "recipient");

            // Sender
            assert null == request.getSender();
            request.setSender("sender");
            assert "sender".equals(request.getSender());
            assert "sender".equals(request.get("X-E3-Originating-Address"));

            request.setSender(null);
            assert null == request.getSender();
            assert !request.containsKey("X-E3-Originating-Address");

            // ConcatenationLimit
            assert null == request.getConcatenationLimit();
            request.setConcatenationLimit(255);
            assert 255 == request.getConcatenationLimit();
            assert "255".equals(request.get("X-E3-Concatenation-Limit"));

            request.setConcatenationLimit(null);
            assert null == request.getConcatenationLimit();
            assert !request.containsKey("X-E3-Concatenation-Limit");

            // ScheduleFor
            assert null == request.getScheduleFor();
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.MILLISECOND, 0);
            Date date = calendar.getTime();
            request.setScheduleFor(date);
            assert date.equals(request.getScheduleFor()) : date + " != " + request.getScheduleFor();

            calendar.setTimeZone(TimeZone.getTimeZone("Europe/London"));
            calendar.set(2012, 9 - 1, 1, 12, 30, 0);
            request.setScheduleFor(calendar.getTime());
            assert "20120901123000".equals(request.get("X-E3-Schedule-For")) : request.get("X-E3-Schedule-For");

            calendar.setTimeZone(TimeZone.getTimeZone("Europe/Berlin"));
            calendar.set(2012, 9 - 1, 1, 12, 30, 0);
            request.setScheduleFor(calendar.getTime());
            assert "20120901113000".equals(request.get("X-E3-Schedule-For")) : request.get("X-E3-Schedule-For");

            calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
            calendar.set(2012, 9 - 1, 1, 12, 30, 0);
            request.setScheduleFor(calendar.getTime());
            assert "20120901133000".equals(request.get("X-E3-Schedule-For")) : request.get("X-E3-Schedule-For");

            request.setScheduleFor(null);
            assert null == request.getScheduleFor();
            assert !request.containsKey("X-E3-Schedule-For");

            // ConfirmDelivery
            assert null == request.getConfirmDelivery();
            request.setConfirmDelivery(true);
            assert Boolean.TRUE.equals(request.getConfirmDelivery());
            assert "on".equals(request.get("X-E3-Confirm-Delivery"));

            request.setConfirmDelivery(false);
            assert Boolean.FALSE.equals(request.getConfirmDelivery());
            assert "off".equals(request.get("X-E3-Confirm-Delivery"));

            request.setConfirmDelivery(null);
            assert null == request.getConfirmDelivery();
            assert !request.containsKey("X-E3-Confirm-Delivery");

            // ReplyPath
            assert null == request.getReplyPath();
            request.setReplyPath("/path");
            assert "/path".equals(request.getReplyPath());
            assert "/path".equals(request.get("X-E3-Reply-Path"));

            request.setReplyPath(null);
            assert null == request.getReplyPath();
            assert !request.containsKey("X-E3-Reply-Path");

            // UserKey
            assert null == request.getUserKey();
            request.setUserKey("123457890");
            assert "123457890".equals(request.getUserKey());
            assert "123457890".equals(request.get("X-E3-User-Key"));

            request.setUserKey(null);
            assert null == request.getUserKey();
            assert !request.containsKey("X-E3-User-Key");

            // SessionReplyPath
            assert null == request.getSessionReplyPath();
            request.setSessionReplyPath("/path");
            assert "/path".equals(request.getSessionReplyPath());
            assert "/path".equals(request.get("X-E3-Session-Reply-Path"));

            request.setSessionReplyPath(null);
            assert null == request.getSessionReplyPath();
            assert !request.containsKey("X-E3-Session-Reply-Path");

            // SessionId
            assert null == request.getSessionId();
            request.setSessionId("1234567890");
            assert "1234567890".equals(request.getSessionId());
            assert "1234567890".equals(request.get("X-E3-Session-ID"));

            request.setSessionId(null);
            assert null == request.getSessionId();
            assert !request.containsKey("X-E3-Session-ID");

            // UserTag
            assert null == request.getUserTag();
            request.setUserTag("123457890");
            assert "123457890".equals(request.getUserTag());
            assert "123457890".equals(request.get("X-E3-User-Tag"));

            request.setUserTag(null);
            assert null == request.getUserTag();
            assert !request.containsKey("X-E3-User-Tag");

            // ValidityPeriod
            assert null == request.getValidityPeriod();

            request.setValidityPeriod(WEEK * 2);
            assert WEEK * 2 == request.getValidityPeriod();
            assert "2w".equals(request.get("X-E3-Validity-Period"));

            request.setValidityPeriod(DAY * 7);
            assert DAY * 7 == request.getValidityPeriod();
            assert "1w".equals(request.get("X-E3-Validity-Period"));

            request.setValidityPeriod(DAY * 2);
            assert DAY * 2 == request.getValidityPeriod();
            assert "2d".equals(request.get("X-E3-Validity-Period"));

            request.setValidityPeriod(HOUR * 24);
            assert HOUR * 24 == request.getValidityPeriod();
            assert "1d".equals(request.get("X-E3-Validity-Period"));

            request.setValidityPeriod(HOUR * 2);
            assert HOUR * 2 == request.getValidityPeriod();
            assert "2h".equals(request.get("X-E3-Validity-Period"));

            request.setValidityPeriod(MINUTE * 60);
            assert MINUTE * 60 == request.getValidityPeriod();
            assert "1h".equals(request.get("X-E3-Validity-Period"));

            request.setValidityPeriod(MINUTE * 2);
            assert MINUTE * 2 == request.getValidityPeriod();
            assert "2m".equals(request.get("X-E3-Validity-Period"));

            request.setValidityPeriod(1000L); // 1s
            assert 0 == request.getValidityPeriod();
            assert "0m".equals(request.get("X-E3-Validity-Period"));

            request.setValidityPeriod(null);
            assert null == request.getValidityPeriod();
            assert !request.containsKey("X-E3-Validity-Period");

            // Custom properties
            request.put("X-E3-Custom-Property", "test1234");
            assert "test1234".equals(request.get("X-E3-Custom-Property"));
            request.remove("X-E3-Custom-Property");
            assert !request.containsKey("X-E3-Custom-Property");
        }

        //
        // toString() (XML generation)
        //

        {
            SendSmsRequest request = new SendSmsRequest(
                    Arrays.asList("message", "message2"),
                    Arrays.asList("recipient", "recipient2"));
            request.setSender("sender");
            request.setConcatenationLimit(255);
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeZone(TimeZone.getTimeZone("Europe/London"));
            calendar.set(2012, 9 - 1, 1, 12, 30, 0);
            request.setScheduleFor(calendar.getTime());
            request.setConfirmDelivery(true);
            request.setReplyPath("/path");
            request.setUserKey("123457890");
            request.setSessionReplyPath("/path");
            request.setSessionId("1234567890");
            request.setUserTag("123457890");
            request.setValidityPeriod(WEEK * 2);

            String xml = request.toString().replaceAll("\r\n", "").replaceAll("\n", "").replaceAll("  <", "<");
            assert "<sendSmsRequest><X-E3-Message>message</X-E3-Message><X-E3-Message>message2</X-E3-Message><X-E3-Recipients>recipient</X-E3-Recipients><X-E3-Recipients>recipient2</X-E3-Recipients><X-E3-Originating-Address>sender</X-E3-Originating-Address><X-E3-Concatenation-Limit>255</X-E3-Concatenation-Limit><X-E3-Schedule-For>20120901123000</X-E3-Schedule-For><X-E3-Confirm-Delivery>on</X-E3-Confirm-Delivery><X-E3-Reply-Path>/path</X-E3-Reply-Path><X-E3-User-Key>123457890</X-E3-User-Key><X-E3-Session-Reply-Path>/path</X-E3-Session-Reply-Path><X-E3-Session-ID>1234567890</X-E3-Session-ID><X-E3-User-Tag>123457890</X-E3-User-Tag><X-E3-Validity-Period>2w</X-E3-Validity-Period></sendSmsRequest>".equals(xml) : xml;
        }

        //
        // SendSmsClient constructor
        //

        {
            final Credentials credentials = new Credentials("user", "pass");

            // endpoint=null
            assertException(new Runnable() {
                public void run() {
                    new SendSmsClient(null, credentials);
                }
            }, IllegalArgumentException.class, "No endpoint provided.");

            // endpoint=""
            assertException(new Runnable() {
                public void run() {
                    new SendSmsClient("", credentials);
                }
            }, IllegalArgumentException.class, "No endpoint provided.");

            // credentials=null
            assertException(new Runnable() {
                public void run() {
                    new SendSmsClient("endpoint", null);
                }
            }, IllegalArgumentException.class, "No credentials provided.");

        }

        //
        // SendSmsClient constructor setters
        //

        {
            final Credentials credentials = new Credentials("user", "pass");
            final SendSmsClient client = new SendSmsClient("endpoint", credentials);

            // endpoint=null
            assertException(new Runnable() {
                public void run() {
                    client.setEndpoint(null);
                }
            }, IllegalArgumentException.class, "No endpoint provided.");

            // endpoint=""
            assertException(new Runnable() {
                public void run() {
                    client.setEndpoint("");
                }
            }, IllegalArgumentException.class, "No endpoint provided.");

            // credentials=null
            assertException(new Runnable() {
                public void run() {
                    client.setCredentials(null);
                }
            }, IllegalArgumentException.class, "No credentials provided.");
        }

        //
        // SendSmsClient constructor getters
        //

        {
            final Credentials credentials = new Credentials("user", "pass");
            final SendSmsClient client = new SendSmsClient("endpoint", credentials);

            assert "endpoint".equals(client.getEndpoint());
            client.setEndpoint("endpoint2");
            assert "endpoint2".equals(client.getEndpoint());

            final Credentials credentials2 = new Credentials("user2", "pass2");
            assert credentials == client.getCredentials();
            client.setCredentials(credentials2);
            assert credentials2 == client.getCredentials();
        }

        //
        // SendSmsClient Path
        //

        {
            final Credentials credentials = new Credentials("user", "pass");
            final SendSmsClient client = new SendSmsClient("endpoint", credentials);

            // Default value
            assert "/submit_sm".equals(client.getPath());

            // path=null
            assertException(new Runnable() {
                public void run() {
                    client.setPath(null);
                }
            }, IllegalArgumentException.class, "No path provided.");

            // path=""
            assertException(new Runnable() {
                public void run() {
                    client.setPath("");
                }
            }, IllegalArgumentException.class, "No path provided.");

            // path invalid
            assertException(new Runnable() {
                public void run() {
                    client.setPath("path");
                }
            }, IllegalArgumentException.class, "The path must start with '/'.");

            client.setPath("/path");
            assert "/path".equals(client.getPath());
        }

        //
        // SendSmsClient Secure
        //

        {
            final Credentials credentials = new Credentials("user", "pass");
            final SendSmsClient client = new SendSmsClient("endpoint", credentials);

            // Default is secure
            assert client.getSecure();
            client.setSecure(false);
            assert !client.getSecure();
        }

        //
        // SendSmsClient Submission
        //

        {
            SendSmsClient client;

            final String login = System.getProperty("login");
            if (login == null) {
                throw new IllegalArgumentException("Please provide -Dlogin=<X-E3-HTTP-Login>");
            }

            final String password = System.getProperty("password");
            if (password == null) {
                throw new IllegalArgumentException("Please provide -Dpassword=<X-E3-HTTP-Password>");
            }

            try {
                client = new SendSmsClient(
                        "sms.dialogue.net", new Credentials(login, password));

                client.setSecure(false);
                testClient(client);
                client.setSecure(true);
                testClient(client);

                client = new SendSmsClient(
                        "sendmsg.dialogue.net", new Credentials(login, password));

                client.setSecure(false);
                testClient(client);
                client.setSecure(true);
                testClient(client);

            } catch (IOException e) {
                e.printStackTrace();
                assert false : e.getMessage();
            }

            // Test wrong password
            assertException(new Runnable() {
                public void run() {
                    SendSmsClient client = new SendSmsClient(
                            "sendmsg.dialogue.net", new Credentials("wrong", "wrong"));
                    client.setSecure(false);
                    try {
                        testClient(client);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }, IOException.class, "Server returned HTTP response code: 401 for URL");

            // Test wrong endpoint
            assertException(new Runnable() {
                public void run() {
                    SendSmsClient client = new SendSmsClient(
                            "wrong", new Credentials("wrong", "wrong"));
                    client.setSecure(false);
                    try {
                        testClient(client);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }, UnknownHostException.class, "");
        }

        //
        // SmsReport
        //

        try {
            final SmsReport report = SmsReport.getInstance("<callback X-E3-Delivery-Report=\"20\" X-E3-ID=\"90A9893BC2B645918034F4C358A062CE\" X-E3-Loop=\"1322229741.93646\" X-E3-Network=\"Orange\" X-E3-Recipients=\"447xxxxxxxxx\" X-E3-Timestamp=\"2011-12-01 18:02:21\" X-E3-User-Key=\"myKey1234\"/>");

            assert report != null;
            assert "90A9893BC2B645918034F4C358A062CE".equals(report.getId());
            assert "447xxxxxxxxx".equals(report.getRecipient());
            assert "20".equals(report.getDeliveryReport());
            assert "myKey1234".equals(report.getUserKey());
            assert 1322762541000L == report.getTimestamp().getTime();
            assert "Orange".equals(report.getNetwork());
            assert "Id: 90A9893BC2B645918034F4C358A062CE, Recipient: 447xxxxxxxxx, DeliveryReport: 20, UserKey: myKey1234, Timestamp: 01/12/11 18:02, Network: Orange".equals(report.toString());

            report.setDeliveryReport("00");
            assert State.Delivered == report.getState();
            assert report.isSuccessful();
            report.setDeliveryReport("1F");
            assert State.Delivered == report.getState();
            assert report.isSuccessful();
            report.setDeliveryReport("20");
            assert State.TemporaryError == report.getState();
            assert !report.isSuccessful();
            report.setDeliveryReport("3F");
            assert State.TemporaryError == report.getState();
            assert !report.isSuccessful();
            report.setDeliveryReport("40");
            assert State.PermanentError == report.getState();
            assert !report.isSuccessful();
            report.setDeliveryReport("7F");
            assert State.PermanentError == report.getState();
            assert !report.isSuccessful();

            report.setDeliveryReport("80");
            assertException(new Runnable() {
                public void run() {
                    report.getState();
                }
            }, IllegalStateException.class, "Unknown delivery report value:");

            report.setDeliveryReport("");
            assert State.Undefined == report.getState();
        } catch (Exception e) {
            assert false : e.toString();
        }

        //
        // SmsReply
        //

        try {
            final SmsReply reply = SmsReply.getInstance("<callback X-E3-Account-Name=\"test\" X-E3-Data-Coding-Scheme=\"00\" X-E3-Hex-Message=\"54657374204D657373616765\" X-E3-ID=\"809EF683F022441DB9C4895AED6382CF\" X-E3-Loop=\"1322223264.20603\" X-E3-MO-Campaign=\"\" X-E3-MO-Keyword=\"\" X-E3-Network=\"Orange\" X-E3-Originating-Address=\"447xxxxxxxxx\" X-E3-Protocol-Identifier=\"00\" X-E3-Recipients=\"1234567890\" X-E3-Session-ID=\"1234567890\" X-E3-Timestamp=\"2011-11-25 12:14:23.000000\" X-E3-User-Data-Header-Indicator=\"0\"/>");

            assert reply != null;
            assert "809EF683F022441DB9C4895AED6382CF".equals(reply.getId());
            assert "447xxxxxxxxx".equals(reply.getSender());
            assert "1234567890".equals(reply.getSessionId());
            assert "54657374204D657373616765".equals(reply.getHexMessage());
            assert "Test Message".equals(reply.getMessage());
            assert 1322223263000L == reply.getTimestamp().getTime() : reply.getTimestamp().getTime();
            assert "Orange".equals(reply.getNetwork());
            assert "Id: 809EF683F022441DB9C4895AED6382CF, Sender: 447xxxxxxxxx, SessionId: 1234567890, HexMessage: 54657374204D657373616765, Message: Test Message, Timestamp: 25/11/11 12:14, Network: Orange".equals(reply.toString());
        } catch (Exception e) {
            assert false : e.toString();
        }
    }

    private static void testClient(SendSmsClient client) throws IOException {
        SendSmsRequest request = new SendSmsRequest(
                "This is a test message.", Arrays.asList("447956247525", "34637975280", "999"));

        SendSmsResponse response = client.sendSms(request);

        assert response != null && response.getMessages() != null &&
                response.getMessages().size() == 3;

        Sms sms;

        sms = response.getMessages().get(0);
        assert sms.isSuccessful();
        assert "447956247525".equals(sms.getRecipient());
        assert sms.getId() != null && sms.getId().length() != 0;
        assert "00".equals(sms.getSubmissionReport());
        assert "".equals(sms.getErrorDescription());

        sms = response.getMessages().get(1);
        assert sms.isSuccessful();
        assert "34637975280".equals(sms.getRecipient());
        assert sms.getId() != null && sms.getId().length() != 0;
        assert "00".equals(sms.getSubmissionReport());
        assert "".equals(sms.getErrorDescription());

        sms = response.getMessages().get(2);
        assert !sms.isSuccessful();
        assert "999".equals(sms.getRecipient());
        assert "".equals(sms.getId());
        assert "43".equals(sms.getSubmissionReport());
        assert !"".equals(sms.getErrorDescription());
    }
}