Compile and run unit tests with:

ant -Dlogin=<X-E3-HTTP-Login> -Dpassword=<X-E3-HTTP-Password>

(Best to use a load testing dummy login.)